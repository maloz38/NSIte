# script des fonctions
def prenoms() :
    fichier = open("prenomsFrance.csv","r",encoding='utf-8')
    liste = []
    ligne = fichier.readline()
    while ligne != ""  :
        try :
            ligne = ligne[:-1]
            l = ligne.split(";")
            try :
                l[0] = int(l[0])
                l[2] = int(l[2])
                l[3] = int(l[3])
                if "%" not in l[1] : liste.append(l)
                ligne = fichier.readline()
            except :
                ligne = fichier.readline()
        except : pass
    fichier.close()
    return liste


# programme principal
listeComplete = prenoms()
