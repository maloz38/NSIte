# Modules ---------------------------------------------------------------
from tkinter import Tk,Label,Entry,Button,StringVar

# Fonctions ---------------------------------------------------------------
def creer_fenetre() :
    fenetre = Tk()
    fenetre.title("Js")
    return fenetre

def creer_widgets() :
    texteHt = Label(fenetre, text = "Prix HT : ")
    texteHt.grid(row = 0 , column = 0)

    ht = Entry(fenetre , textvariable = StringVar())
    ht.grid(row = 0 , column = 1)

    texteTva = Label(fenetre, text = "Taux TVA : ")
    texteTva.grid(row = 0 , column = 2)

    tva = Entry(fenetre , textvariable = StringVar())
    tva.grid(row = 0 , column = 3)

    boutonCalcul = Button(fenetre, text = "Valider",command = calcul)
    boutonCalcul.grid(row = 0, column = 4)

    boutonReset = Button(fenetre, text = "Raz" ,command = reset)
    boutonReset.grid(row = 0, column = 5)

    affichage = Label(fenetre, text = "")
    affichage.grid(row = 1 , column = 0)

    return texteHt,ht,texteTva,tva,affichage



# Fonctions
def calcul() :
    # lecture prix HT dans saisieHt
    prixHt = ht.get()
    if (prixHt == "") : prixHt = 0
    prixHt = float(prixHt)
    # lecture taux Tva dans tauxTva
    tauxTva = tva.get()
    if (tauxTva == "") : tauxTva = 0
    tauxTva = float(tauxTva)
    # Calcul prix TTC
    prixTtc = prixHt * tauxTva/100 + prixHt
    affichage.configure(text = "Prix TTC : "+str(prixTtc)+" €")

def reset() :
    ht.delete(0,20)
    tva.delete(0,20)
    affichage.configure(text = "")


# Main
fenetre = creer_fenetre()
texteHt,ht,texteTva,tva,affichage = creer_widgets()

fenetre.mainloop()




