const section = document.querySelector("section");

function creationFieldset(article,para){
    let fieldset = document.createElement("fieldset");
    let legend = document.createElement("legend");
    legend.innerText = para;
    fieldset.append(legend);
    let p = document.createElement("p");
    p.innerText = conv(article,para);
    fieldset.append(p);
    return fieldset
}

function creation(article){
    //div
    let div = document.createElement("div");
    section.append(div);

    //fieldset1
    let fieldset1 = document.createElement("fieldset");
    fieldset1.setAttribute("class","p");
    div.append(fieldset1);
    let legend0 = document.createElement("legend");
    let texte = "De "+article.expediteur+" le "+article.quand;
    legend0.innerText = texte;
    fieldset1.append(legend0);

    //fieldset2 et 3 
    fieldset1.append( creationFieldset(article,"objet"));
    fieldset1.append( creationFieldset(article,"texte"));       
}

function conv(article,para){
    if (para === "objet"){return article.objet;}
    if (para === "texte"){return article.texte;}

}

function ecriture(){
    fetch("../tchat.json")
    .then(reponse => reponse.json())
    .then(articles => {
        section.replaceChildren();
        for (let i = 0 ; i < articles.length ;i++){
            creation(articles[i]);
        }
    })
};

function refresh_div() {setInterval('ecriture()', 1000);}
refresh_div();  