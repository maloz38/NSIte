from turtle import *
def decor() :
    # Tracé du sol et du panneau
    panneau = Turtle()
    panneau.color("red")
    panneau.up()
    panneau.goto(300,-200)
    panneau.down()
    panneau.goto(300,200)
    panneau.goto(300,100)
    panneau.goto(250,100)
    panneau.up()
    panneau.goto(-300,-200)
    panneau.down()
    panneau.pensize(10)
    panneau.goto(300,-200)

    # Tracé du basketteur
    Screen().addshape("basketteur.gif")
    basketteur = Turtle()
    basketteur.shape("basketteur.gif")
    basketteur.up()
    basketteur.goto(-300,-120)

    # Tracé du ballon
    Screen().addshape("ballon.gif")
    ballon = Turtle()
    ballon.shape("ballon.gif")
    ballon.up()
    xb,yb = -300,-40
    ballon.goto(xb,yb)
    ballon.down()

    return ballon

