# importation des bibliothèques
from turtle import *
from math import cos,sin,pi
from bibli_basket import decor

# construction du décor par l'appel de la fonction decor()
ballon = decor()
xb = -300
yb = -40
# saisi vitesse et angle
v = int(numinput("", "vitesse ?",minval = 0, maxval = 500))
angle = int(numinput("", "angle ?",minval = 0, maxval = 90))
angle = angle * pi / 180

# lancer
x = xb
y = yb
t = 0
for i in range(50) :
    x = v*cos(angle)*t + xb
    y = -9.81/2*t**2 + v*sin(angle)*t + yb
    ballon.goto(x,y)
    ballon.dot(5)
    t = t + 0.1
   
# à laisser
exitonclick()

