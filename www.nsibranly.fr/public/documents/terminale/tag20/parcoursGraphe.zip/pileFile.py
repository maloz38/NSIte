class Pile :
    def __init__(self) :
        self.l = []

    def __str__(self) :
        s = "pile : "
        for e in self.l : s += str(e) + " "
        return s

    def empiler(self,e) :
        self.l.append(e)

    def depiler(self) :
        return self.l.pop()

    def estVide(self) :
        return self.l == []

class File :
    def __init__(self) :
        self.l = []

    def __str__(self) :
        s = "file : "
        for e in self.l : s += str(e) + " "
        return s

    def enfiler(self,e) :
        self.l.append(e)

    def defiler(self) :
        return self.l.pop(0)

    def estVide(self) :
        return self.l == []
