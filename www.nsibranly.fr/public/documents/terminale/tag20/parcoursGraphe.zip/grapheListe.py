from graphviz import Digraph , Graph
graphe = Graph(format = 'png' , filename = 'graphe')
from pileFile import File,Pile

class Gliste :
    def __init__(self, oriente = False) :
        self.dic = {}

    def ajout_arete(self,nd1,nd2,valeur = None) :
        nd1,nd2 = str(nd1) , str(nd2)
        if nd1 in self.dic :
            self.dic[nd1].append(nd2)
        else : self.dic[nd1] = [nd2]
        if nd2 in self.dic :
            self.dic[nd2].append(nd1)
        else : self.dic[nd2] = [nd1]

    def trace(self) :
        deja_trace = []
        for nd1 in self.dic :
            for nd2 in self.dic[nd1] :
                if {nd1,nd2} not in deja_trace  :
                    graphe.edge(nd1,nd2)
                    deja_trace.append({nd1,nd2})
        graphe.view()



# Main
g = Gliste()
g.ajout_arete('A', 'B')
g.ajout_arete('A', 'C')
g.ajout_arete('B', 'D')
g.ajout_arete('D', 'C')
g.ajout_arete('B', 'E')
g.ajout_arete('D', 'E')
g.ajout_arete('E', 'F')
g.ajout_arete('E', 'G')
g.ajout_arete('F', 'G')
g.ajout_arete('G', 'H')

g.trace()
