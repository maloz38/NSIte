from bibliRedim import Redim

class RedimTp(Redim) :
    def __init__(self):
        Redim.__init__(self)

    def getPixel(self) :
        return self.pixel

    def setResultat(self,liste) :
        self.resultat = liste

    def redimensionnement(self) :
        pix = self.getPixel()
        n = len(pix)
        resultat = [0 for i in range(n)]


        self.setResultat(resultat)
        self.redWay()


# Main
R = RedimTp()
R.mainloop()

