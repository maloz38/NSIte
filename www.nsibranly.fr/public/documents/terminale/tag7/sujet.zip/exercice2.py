from math import sqrt

def lectureDonnees(nomFichier):
    """
    Paramètres : nomFichier (string) : nom d'un fichier csv
    Sortie : liste de liste dont les éléments sont les lignes du fichier

    Lit les données du fichier en paramètre et retourne une liste contenant pour chaque élève de Poudlard,
    une liste du type [Nom (string) , Courage(int) , Loyaute(int) , Sagesse(int) , Malice(int), Maison(string) ]
    """
    fichier = open(nomFichier,"r")
    liste = []
    ligne = fichier.readline()
    ligne = fichier.readline()
    while ligne != ""  :
        ligne = ligne[:-1]
        ligne = ligne.split(";")
        for i in range(1,5) :
            ligne[i] = float(ligne[i])
        liste.append(ligne)
        ligne = fichier.readline()
    fichier.close()
    return liste


def echange(liste , i , j) :
    """
    Paramètres: liste (list) : liste
                i (int) : indice d'un élément de cette liste
                j (int) : indice d'un élément de cette liste
    Sortie : True si l'échange des éléments d'indice i et j a été effectué avec succés, False sinon
    """
    n = len(liste)-1
    if i < 0 or i > n  : return False
    if j < 0 or j > n  : return False
    tmp = liste[i]
    liste[i] = liste[j]
    liste[j] = tmp
    return True


def triSelection(liste) :
    """
    Paramètres: liste (list) : liste
    Sortie : liste (list) : même liste, mais triée
    """
    n = len(liste)
    for i in range(len(liste)) :
        jMin = i
        for j in range(i+1,n) :
            if liste[j]<liste[jMin] :
                jMin = j
        echange(liste,i,jMin)
    return liste

def triInsertion(liste) :
    """
    Paramètres: liste (list) : liste
    Sortie : liste (list) : même liste, mais triée
    """
    n = len(liste)
    for i in range(1,n) :
        val = liste[i]
        j = i-1
        while liste[j] > val and j >=0 :
            liste[j+1] = liste[j]
            j = j - 1
        liste[j+1] = val
    return liste


# Main
inconnue = ["Camilla",8,6,6,6]







