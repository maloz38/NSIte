from math import sqrt
from matplotlib.pyplot import legend,grid,show,scatter


def donneesIris(nomFichier : str) -> list:
    """
        Paramètres : nom de fichier texte (string)
        Sortie : liste de liste dont les éléments sont les lignes du fichier
    """
    fichier = open(nomFichier,"r",encoding='utf-8')
    liste = []
    ligne = fichier.readline()
    ligne = fichier.readline()
    while ligne != ""  :
        ligne = ligne[:-1]
        ligne = ligne.split(",")
        ligne.append(None)
        for i in range(4) :
            ligne[i] = float(ligne[i])
        liste.append(ligne)
        ligne = fichier.readline()
    fichier.close()
    return liste



# Main
donnees = donneesIris("iris.txt")





