from matplotlib.pyplot import legend,grid,show,scatter

x1 = [1, 2, 3, 4, 5]
y1 = [1, 4, 9, 16, 25]
x2 = [1, 2, 3, 4, 5]
y2 = [9, 2, 1, 5, 10]

scatter(x1, y1, c = 'red' , label='setosa')
scatter(x2, y2, c = 'yellow',label='versicolor')

legend()
grid(True)
show()
