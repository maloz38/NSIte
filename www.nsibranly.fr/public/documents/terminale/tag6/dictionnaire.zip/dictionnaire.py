def motsFrancais(nomFichier : str) -> list:
    """
        Paramètres : nom de fichier texte (string)
        Sortie : liste dont les éléments sont les lignes du fichier
                (string)
    """
    fichier = open(nomFichier,"r",encoding='utf-8')
    liste = []
    ligne = fichier.readline()
    while ligne != ""  :
        try :
            ligne = ligne[:-1]
            ligne = convert(ligne)
            try :
                liste.append(ligne)
                ligne = fichier.readline()
            except :
                ligne = fichier.readline()
        except : pass
    fichier.close()
    return liste

def convert(mot : str) ->str :
    """
        Paramètres : string
        Sortie : même string, mais sans l'accentuation
    """
    new = ""
    for c in mot :
        if c in "éèëê" : new += "e"
        elif c in "â" : new += "a"
        elif c in "îï" : new += "i"
        elif c in "ûü" : new += "u"
        elif c in "ôö" : new += "i"
        elif c in " -_" : new += ""
        else : new += c
    return new



# Programme principal
l = motsFrancais("mots.txt")
for i in range(1000,100000,10000) :
    print(l[i])
